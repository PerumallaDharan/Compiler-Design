#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_RULES 10
#define MAX_SYMBOLS 10

// Structure definitions
struct ProductionRule
{
    char nonTerminal;
    char body[MAX_SYMBOLS];
};

struct FirstSet
{
    char nonTerminal;
    char first[MAX_SYMBOLS];
};

struct FollowSet
{
    char nonTerminal;
    char follow[MAX_SYMBOLS];
};

// Function to check if a symbol is a terminal
int isTerminal(char symbol)
{
    return islower(symbol);
}

// Function to check if a symbol is epsilon
int isEpsilon(char symbol)
{
    return symbol == '@';
}

// Function to find the index of a non-terminal in the rules array
int findNonTerminalIndex(char nonTerminal, struct ProductionRule rules[MAX_RULES], int numRules)
{
    for (int i = 0; i < numRules; i++)
    {
        if (rules[i].nonTerminal == nonTerminal)
        {
            return i;
        }
    }
    return -1; // Not found
}

// Function prototypes
void computeFirstSet(struct ProductionRule rules[MAX_RULES], int numRules, struct FirstSet firstSets[MAX_RULES]);
void computeFollowSet(struct ProductionRule rules[MAX_RULES], int numRules, struct FirstSet firstSets[MAX_RULES], struct FollowSet followSets[MAX_RULES]);
void displayGrammar(struct ProductionRule rules[MAX_RULES], int numRules);
void displayFirstSets(struct FirstSet firstSets[MAX_RULES], int numRules);
void displayFollowSets(struct FollowSet followSets[MAX_RULES], int numRules);

int main()
{
    int numRules;
    printf("Enter the number of production rules: ");
    scanf("%d", &numRules);

    struct ProductionRule rules[MAX_RULES];
    struct FirstSet firstSets[MAX_RULES];
    struct FollowSet followSets[MAX_RULES];

    // Input production rules
    printf("Enter the production rules:\n");
    for (int i = 0; i < numRules; i++)
    {
        printf("Rule %d: ", i + 1);
        scanf(" %c -> %s", &rules[i].nonTerminal, rules[i].body);
    }

    computeFirstSet(rules, numRules, firstSets);
    computeFollowSet(rules, numRules, firstSets, followSets);

    // Display the grammar rules
    printf("\nGrammar Rules:\n");
    displayGrammar(rules, numRules);

    // Display FIRST sets
    printf("\nFIRST sets:\n");
    displayFirstSets(firstSets, numRules);

    // Display FOLLOW sets
    printf("\nFOLLOW sets:\n");
    displayFollowSets(followSets, numRules);

    return 0;
}

// Function to display the rules of the grammar
void displayGrammar(struct ProductionRule rules[MAX_RULES], int numRules)
{
    for (int i = 0; i < numRules; i++)
    {
        printf("Rule %d: %c -> %s\n", i + 1, rules[i].nonTerminal, rules[i].body);
    }
}

// Function to display the FIRST sets
void displayFirstSets(struct FirstSet firstSets[MAX_RULES], int numRules)
{
    for (int i = 0; i < numRules; i++)
    {
        printf("FIRST(%c): {%s}\n", firstSets[i].nonTerminal, firstSets[i].first);
    }
}

// Function to display the FOLLOW sets
void displayFollowSets(struct FollowSet followSets[MAX_RULES], int numRules)
{
    for (int i = 0; i < numRules; i++)
    {
        printf("FOLLOW(%c): {%s}\n", followSets[i].nonTerminal, followSets[i].follow);
    }
}

void computeFirstSet(struct ProductionRule rules[MAX_RULES], int numRules, struct FirstSet firstSets[MAX_RULES])
{
    for (int i = 0; i < numRules; i++)
    {
        firstSets[i].nonTerminal = rules[i].nonTerminal;
        memset(firstSets[i].first, '\0', sizeof(firstSets[i].first)); // Initialize first set

        // If the body of the rule starts with a terminal or epsilon, add it to the FIRST set
        if (isTerminal(rules[i].body[0]) || isEpsilon(rules[i].body[0]))
        {
            firstSets[i].first[0] = rules[i].body[0];
        }
        else
        {
            // If the body starts with a non-terminal, compute its FIRST set
            int j = 0;
            int k = 0;

            while (j < strlen(rules[i].body) && isEpsilon(firstSets[findNonTerminalIndex(rules[i].body[j], rules, numRules)].first[0]))
            {
                // If the first symbol of the non-terminal's FIRST set is epsilon,
                // add it to the current non-terminal's FIRST set and move to the next symbol
                strcat(firstSets[i].first, firstSets[findNonTerminalIndex(rules[i].body[j], rules, numRules)].first);
                j++;
            }

            // Add the first non-epsilon symbol of the non-terminal's FIRST set to the current non-terminal's FIRST set
            while (j < strlen(rules[i].body) && !isEpsilon(firstSets[findNonTerminalIndex(rules[i].body[j], rules, numRules)].first[k]))
            {
                firstSets[i].first[strlen(firstSets[i].first)] = firstSets[findNonTerminalIndex(rules[i].body[j], rules, numRules)].first[k];
                k++;
            }

            // If the entire body can derive epsilon, add epsilon to the FIRST set
            if (j == strlen(rules[i].body))
            {
                strcat(firstSets[i].first, "@");
            }
        }
    }
}

void computeFollowSet(struct ProductionRule rules[MAX_RULES], int numRules, struct FirstSet firstSets[MAX_RULES], struct FollowSet followSets[MAX_RULES])
{
    // Initialize FOLLOW sets
    for (int i = 0; i < numRules; i++)
    {
        followSets[i].nonTerminal = rules[i].nonTerminal;
        memset(followSets[i].follow, '\0', sizeof(followSets[i].follow));
    }

    // Add $ to the start symbol's FOLLOW set
    followSets[0].follow[0] = '$';

    // Iterate until there are no changes to any FOLLOW set
    int changed = 1;
    while (changed)
    {
        changed = 0;

        // Iterate over each production rule
        for (int i = 0; i < numRules; i++)
        {
            // Iterate over each symbol in the rule's body
            for (int j = 0; j < strlen(rules[i].body); j++)
            {
                // If the symbol is a non-terminal, update its FOLLOW set
                if (!isTerminal(rules[i].body[j]))
                {
                    int nonTerminalIndex = findNonTerminalIndex(rules[i].body[j], rules, numRules);
                    int k = j + 1;

                    // Case 1: Non-terminal followed by terminal
                    while (k < strlen(rules[i].body) && isTerminal(rules[i].body[k]))
                    {
                        if (strchr(followSets[nonTerminalIndex].follow, rules[i].body[k]) == NULL)
                        {
                            // If the terminal is not already in the FOLLOW set, add it
                            followSets[nonTerminalIndex].follow[strlen(followSets[nonTerminalIndex].follow)] = rules[i].body[k];
                            changed = 1;
                        }
                        k++;
                    }

                    // Case 2: Non-terminal followed by another non-terminal
                    if (k < strlen(rules[i].body) && !isEpsilon(firstSets[findNonTerminalIndex(rules[i].body[k], rules, numRules)].first[0]))
                    {
                        // Add the FIRST set of the next non-terminal to the current non-terminal's FOLLOW set
                        int l = 0;
                        while (l < strlen(firstSets[findNonTerminalIndex(rules[i].body[k], rules, numRules)].first))
                        {
                            if (strchr(followSets[nonTerminalIndex].follow, firstSets[findNonTerminalIndex(rules[i].body[k], rules, numRules)].first[l]) == NULL)
                            {
                                // If the symbol is not already in the FOLLOW set, add it
                                followSets[nonTerminalIndex].follow[strlen(followSets[nonTerminalIndex].follow)] = firstSets[findNonTerminalIndex(rules[i].body[k], rules, numRules)].first[l];
                                changed = 1;
                            }
                            l++;
                        }
                    }

                    // Case 3: Non-terminal followed by epsilon or non-terminal with epsilon in its FIRST set
                    if (k == strlen(rules[i].body) || isEpsilon(firstSets[findNonTerminalIndex(rules[i].body[k], rules, numRules)].first[0]))
                    {
                        // Add the FOLLOW set of the left-hand side non-terminal to the current non-terminal's FOLLOW set
                        int m = 0;
                        while (m < strlen(followSets[i].follow))
                        {
                            if (strchr(followSets[nonTerminalIndex].follow, followSets[i].follow[m]) == NULL)
                            {
                                // If the symbol is not already in the FOLLOW set, add it
                                followSets[nonTerminalIndex].follow[strlen(followSets[nonTerminalIndex].follow)] = followSets[i].follow[m];
                                changed = 1;
                            }
                            m++;
                        }
                    }
                }
            }
        }
    }
}