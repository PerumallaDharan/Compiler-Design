#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_NON_TERMINALS 10
#define MAX_TERMINALS 10

// Structure to store FIRST and FOLLOW sets
struct FirstFollow {
    char nonTerminal;
    char firstSet[MAX_TERMINALS];
    char followSet[MAX_TERMINALS];
};

// Structure to represent a production rule
struct ProductionRule {
    char nonTerminal;
    char production[MAX_TERMINALS];
};

void computeFirstSets(struct ProductionRule* rules, int numRules, struct FirstFollow* ffSets, int numNonTerminals) {
    for (int i = 0; i < numNonTerminals; i++) {
        ffSets[i].nonTerminal = rules[i].nonTerminal;
        strcpy(ffSets[i].firstSet, rules[i].production);
    }
}

void computeFollowSets(struct ProductionRule* rules, int numRules, struct FirstFollow* ffSets, int numNonTerminals) {
    // Placeholder function, not implemented for this example
}

int main() {
    int numRules;

    printf("Enter the number of production rules: ");
    scanf("%d", &numRules);

    struct ProductionRule* rules = (struct ProductionRule*)malloc(numRules * sizeof(struct ProductionRule));
    if (rules == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    for (int i = 0; i < numRules; i++) {
        printf("Enter non-terminal for rule %d: ", i + 1);
        scanf(" %c", &rules[i].nonTerminal);

        printf("Enter production for rule %d: ", i + 1);
        scanf("%s", rules[i].production);
    }

    struct FirstFollow ffSets[MAX_NON_TERMINALS];

    // Calculate FIRST sets
    computeFirstSets(rules, numRules, ffSets, numRules);

    printf("FIRST sets:\n");
    for (int i = 0; i < numRules; i++) {
        printf("FIRST(%c) = {%s}\n", ffSets[i].nonTerminal, ffSets[i].firstSet);
    }

    // Calculate FOLLOW sets
    computeFollowSets(rules, numRules, ffSets, numRules);

    printf("FOLLOW sets:\n");
    for (int i = 0; i < numRules; i++) {
        printf("FOLLOW(%c) = {%s}\n", ffSets[i].nonTerminal, ffSets[i].followSet);
    }

    free(rules);

    return 0;
}